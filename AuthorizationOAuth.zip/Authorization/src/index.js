const express = require("express")
const connect = require("./config/db")
const userController = require("./controller/user.controller")
const productController = require("./controller/product.controller")
const {register,login,generateToken} = require("./controller/auth.controller")
const passport = require("./config/google-auth")
const app = express()

app.use(express.json())
app.use("/users",userController)
app.use("/register",register)
app.use("/login",login) 
app.use("/products", productController)

app.get('/auth/google',
  passport.authenticate('google', { scope: ['profile','email'] }));
 
  app.get(
    '/auth/google/callback', 
      passport.authenticate('google', { failureRedirect: '/login', session:false } ),
    
      function(req, res) {
        const token = generateToken(req.user)
        return res.status(200).send({user:req.user,token})
      }
    )

app.listen(5000, async() => {  
    try{
        await connect();
        console.log("listening on port 5000")
    }
    catch(err){
        console.log(err.message)
    }
})
 



 