const express = require("express")
const path= require("path")

const transporter = require("../configs/mail")
const Product = require("../model/product.model")

const router = express.Router();

router.get("",async(req,res) => {
    try{
        const page = req.query.page || 1
        const pagesize = req.query.pagesize || 10
        const skip = (page-1)*pagesize
        
        const products = await Product.find().skip(skip).limit(pagesize).lean().exec()
        const totalPages = Math.ceil((await Product.find().countDocuments())/pagesize)
        return res.status(200).send({products,totalPages})
    }
    catch(err){
        return res.status(200).send({message:err.message})
    }
})

router.post("/", async(req,res) => {
    try{
        const product = await Product.create(req.body)
         info = transporter.sendMail({
            from: '"masai school " <abc@masai.com>', 
            to: product.email, 
            subject: "Your product is successfully created", 
            text:  "Dear, Sir/Ma'am Your product is successfully created" 
          });

          return res.status(201).send({message:"Welcome to masai school"})
    }
    catch(err){
        return res.status(500).send({message:err.message})
    }
}) 

module.exports=router;