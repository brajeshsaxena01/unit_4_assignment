const mongoose = require("mongoose")

module.exports=()=>{
    return mongoose.connect("mongodb+srv://braj:braj_123@cluster0.jpxr8.mongodb.net/pagination?retryWrites=true&w=majority")
}