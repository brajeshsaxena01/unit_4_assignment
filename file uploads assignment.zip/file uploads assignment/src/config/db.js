const mongoose = require("mongoose")

module.exports=()=>{
    return mongoose.connect("mongodb+srv://braj:braj_123@cluster0.ta7rm.mongodb.net/file_upload?retryWrites=true&w=majority")
    
}