// mongodb+srv://validation:validation@cluster0.kou7r.mongodb.net/validation?retryWrites=true&w=majority

const start = require("./server")
 
start()