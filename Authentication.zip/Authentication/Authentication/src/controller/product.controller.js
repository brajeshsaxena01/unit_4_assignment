const express = require("express")
const router = express.Router()
const authenticate = require("../middleware/authenticate")
const Product = require("../model/product.model")
router.post("",authenticate,async(req,res)=>{
    req.body.user_id=req.userID; 
    try {
        const product = await Product.create(req.body)  
        return res.status(200).send(product)
    } catch (error) {
        return res.status(500).send({message:error.message})
    }
})
router.get("",async(req,res)=>{
    req.body.user_id=req.userID;
    try {
        const product = await Product.find().lean().exec()
        return res.status(200).send(product)
    } catch (error) {
        return res.status(500).send({message:error.message})
    }
})
module.exports=router